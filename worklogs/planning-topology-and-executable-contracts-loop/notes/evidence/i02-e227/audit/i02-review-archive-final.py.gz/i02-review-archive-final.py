"""Archive actual E227 final proof; refuses incomplete/non-green producer runs."""
from pathlib import Path
import gzip,hashlib,json,platform,subprocess,sys,xml.etree.ElementTree as ET
from fa.inner_loop import slice_verification as v
ROOT=Path.cwd();CACHE=Path('/home/user/.cache/fa-runtime');P=CACHE/'i02-review-final-proof-v2'
assert (CACHE/'i02-review-final-proof-v2.rc').read_text().strip()=='0'
rows=json.loads((P/'results.json').read_text());assert len(rows)==46
baseline=json.loads((P/'baseline.json').read_text());assert baseline['source_commit']=='b2b28300aa9536b9b059bb18867f7bd7667efdfa'
report,detail=v._parse_junit_report(P/'baseline.xml',run_id=baseline['run_id'])
assert baseline['exit_code']==0 and report is not None and len(report.outcomes)==927 and all(o is v._JUnitOutcome.PASSED for o in report.outcomes.values()),detail
manifest=json.loads((P/'baseline-collection.json').read_text());assert sorted(report.outcomes)==manifest
seen=set()
for row in rows:
 assert row['name'] not in seen;seen.add(row['name'])
 assert row['check']['verdict']=='proven' and row['probe']['outcome']=='pass'
 assert row['runner']['exit_code']==1 and row['runner']['outcome']=='fail'
 assert row['manifest_matches'] and row['ordered'] and row['started']>=baseline['completed']
 assert row['counts']['failed']>0 and row['counts']['skipped']==0
 assert sum(row['counts'].values())==row['expected_count']
 r,e=v._parse_junit_report(P/(row['name']+'.xml'),run_id=row['run_id'])
 assert r is not None,e
 assert len(r.outcomes)==row['expected_count'] and r.failure_count==row['counts']['failed']
 assert sorted(r.outcomes)==[n for n in manifest if n.partition('::')[0] in row['command'].split()],row['name']
 assert row['report_detail']==''
assert sum(r['kind']=='FUNCTIONAL' for r in rows)==40
assert sum(r['kind']=='CONSTRAINT' for r in rows)==1
assert sum(r['kind']=='SUPPLEMENTAL' for r in rows)==5
s6=[r for r in rows if r['slice']=='SLICE6'];assert len(s6)==21 and all(r['expected_count']==537 for r in s6)
inputs=json.loads((P/'inputs.json').read_text());assert all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest for name,digest in inputs.items())
assert subprocess.check_output(['git','status','--porcelain=v1'])==b''
comparison=json.loads((CACHE/'i02-review-final-suite-comparison.json').read_text());assert comparison['new_failures']==[]
assert (CACHE/'i02-review-final-just-check-v2.rc').read_text().strip()=='1'
check=(CACHE/'i02-review-final-just-check-v2.log').read_text()
for label in ['lock-check','lint (ruff+format+deptry+pylint-gap)','typecheck (mypy strict)','typecheck (pyrefly)','authoring-check','contracts (dep+pc+log-kind+no-mock-dc)','shell-syntax (bash -n)']:
 assert '✓ '+label in check,label
assert '5083 passed, 12 skipped, 1 xfailed' in check and 'Total coverage: 83.37%' in check
assert '27 cli.py function coverage floors met (78 functions scanned)' in (CACHE/'i02-review-final-cli-floor.log').read_text()
OUT=ROOT/'worklogs/planning-topology-and-executable-contracts-loop/notes/evidence/i02-e227';OUT.mkdir(exist_ok=False)
files={}
def put(path,name):
 raw=path.read_bytes();compressed=gzip.compress(raw,mtime=0);(OUT/name).parent.mkdir(parents=True,exist_ok=True);(OUT/name).write_bytes(compressed)
 files[name]={'sha256_uncompressed':hashlib.sha256(raw).hexdigest(),'sha256_gzip':hashlib.sha256(compressed).hexdigest(),'bytes_uncompressed':len(raw)}
for path in sorted(P.iterdir()):
 if path.is_file():put(path,'ordered/'+path.name+'.gz')
for name in ['i02-review-archive-final.py','i02-review-final-proof-v2.py','i02-review-final-proof-v2.log','i02-review-final-proof-v2.rc','i02-review-suite-comparison.py','i02-review-final-suite-comparison.json','i02-review-final-suite-comparison.log','i02-review-final-just-check-v2.log','i02-review-final-just-check-v2.rc','i02-review-final-repository-v2.xml','i02-review-final-check-v2.uuid','i02-review-final-cli-floor.log','i02-review-final-symbol-inventory.json']:
 put(CACHE/name,('repository/' if any(x in name for x in ['just-check','repository','check-v2.uuid','cli-floor','suite-comparison']) else 'audit/')+name+'.gz')
for name in ['coverage.json','coverage.xml']:put(ROOT/name,'repository/'+name+'.gz')
hook=ROOT/'.git/hooks/commit-msg';assert len(hook.read_bytes())==208
metadata={'source_commit':baseline['source_commit'],'comparison_baseline':comparison['baseline_commit'],'local_environment':{'python':sys.version,'platform':platform.platform(),'executable':sys.executable},'encoding':'gzip; original bytes retained; verify both hashes','scope':'local implementation/diff-review proof, NOT deployed Ubuntu/Docker, OS isolation or I03 acceptance','baseline':baseline,'count':927,'producer_invocations':46,'functional':40,'constraint':1,'supplemental':5,'slice6_cases_per_invocation':537,'slice6_invocations':21,'mutations_duration_sum_s':sum(r['check']['duration_s'] for r in rows),'check_rc':1,'repository_summary':{'passed':5083,'failed':1,'skipped':12,'xfailed':1,'total':5097,'duration_s':1212.45,'coverage_percent':83.37},'comparison':{k:comparison[k] for k in ['new_failures','common_failures','baseline_only_failures','missing_ids']},'new_ids':len(comparison['new_ids']),'foreign_commit_msg_hook':{'bytes':208,'sha256':hashlib.sha256(hook.read_bytes()).hexdigest()},'restoration':'All frozen src/tests/scripts and plan/schema inputs unchanged; clean git status after final proof, before documentation closeout. Overlay only; no checkout source mutation.','files':files}
(OUT/'manifest.json').write_text(json.dumps(metadata,indent=2)+'\n')
print('Archived',len(files),'files; all46 fresh producer proofs/native manifests verified; actual check rc1 retained.')
