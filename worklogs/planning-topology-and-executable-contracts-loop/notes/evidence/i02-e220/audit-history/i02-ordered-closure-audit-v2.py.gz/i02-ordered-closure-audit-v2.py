"""E220 ordered retained-I02 audit. No tracked files edited; baseline must complete before kills."""
import concurrent.futures,dataclasses,hashlib,json,os,shlex,subprocess,sys,time,uuid
from pathlib import Path
from fa.inner_loop.plan_ids import extract_plan_ids
from fa.inner_loop import slice_verification as v
ROOT=Path.cwd();OUT=Path('/home/user/.cache/fa-runtime/i02-ordered-closure-audit-v2');OUT.mkdir(exist_ok=False)
PLAN='worklogs/planning-topology-and-executable-contracts-loop/increments/increment-02-verify-gate-and-kill-checks.md'
SCHEMA='worklogs/planning-topology-and-executable-contracts-loop/notes/artifact-schema-and-grammar.md'
records=extract_plan_ids((ROOT/PLAN).read_text()).slice_records
assert len(records)==7
cases=[]
for record in records:
 directives=v.parse_kill_directives(record)
 functional={k for k,cls,_ in record.contracts if cls=='FUNCTIONAL'}
 assert functional<=directives.keys(),(record.slice_id,functional-directives.keys())
 for name,directive in directives.items():cases.append((record,name,directive,'FUNCTIONAL' if name in functional else 'CONSTRAINT'))
assert len(cases)==41 and sum(kind=='FUNCTIONAL' for _,_,_,kind in cases)==40
s6=next(r for r in records if r.slice_id=='SLICE6')
assert s6.test_paths==('tests/test_verify_gate_live.py',)
cases += [(s6,'SUP-GUARD',v.KillDirective(v.KillOperator.REMOVE_CALL,'src/fa/inner_loop/tools/workflow_tool.py','build_invoke_workflow_tool.handler','_requires_acquisition',0),'SUPPLEMENTAL'),(s6,'SUP-CONTEXT',v.KillDirective(v.KillOperator.REMOVE_CALL,'src/fa/inner_loop/tools/workflow_tool.py','_child_run_context','begin_run',0),'SUPPLEMENTAL')]
watched=sorted(set(subprocess.check_output(['git','ls-files','--','src/**/*.py','tests/**/*.py','scripts/**/*.py'],text=True).splitlines()+[PLAN,SCHEMA]))
def hashes():return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in watched}
frozen=hashes();status=subprocess.check_output(['git','status','--porcelain=v1'])
(OUT/'inputs.json').write_text(json.dumps(frozen,indent=2)+'\n')
paths=sorted({p for r in records for p in r.test_paths}|{'tests/test_skill_grammar_emit.py','tests/test_planner_emits_schema4.py','tests/test_plan_grammar_live_chain.py'})
env=os.environ.copy();runid=uuid.uuid4().hex;env[v.JUNIT_RUN_ID_ENV]=runid
collect=subprocess.run([sys.executable,'-m','pytest',*paths,'--collect-only','-q'],cwd=ROOT,env=env,capture_output=True,text=True,check=True)
manifest=sorted(l for l in collect.stdout.splitlines() if l.startswith('tests/') and '::' in l)
assert len(manifest)==len(set(manifest))>487
(OUT/'baseline-collection.json').write_text(json.dumps(manifest,indent=2)+'\n')
started=time.time();baseline_command=[sys.executable,'-m','pytest',*paths,'-q','--tb=short','-p','fa.inner_loop.junit_nodeid_plugin','--junitxml='+str(OUT/'baseline.xml')]
print(json.dumps({'phase':'baseline_started','time':started,'command':baseline_command,'collected':len(manifest)}),flush=True)
with (OUT/'baseline.log').open('w') as log:
 baseline=subprocess.run(baseline_command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
ended=time.time();report,detail=v._parse_junit_report(OUT/'baseline.xml',run_id=runid)
assert baseline.returncode==0 and report is not None,(baseline.returncode,detail)
assert sorted(report.outcomes)==manifest and all(o.value=="passed" for o in report.outcomes.values())
assert hashes()==frozen and subprocess.check_output(['git','status','--porcelain=v1'])==status
baseline_metadata={'command':baseline_command,'run_id':runid,'rc':baseline.returncode,'started':started,'completed':ended,'count':len(manifest),'seconds':ended-started}
(OUT/'baseline.json').write_text(json.dumps(baseline_metadata,indent=2)+'\n')
print(json.dumps({'phase':'BASELINE_PASSED_BEFORE_ANY_MUTATION',**baseline_metadata}),flush=True)

def run(case):
 record,name,directive,kind=case
 begin_wall=time.time();assert begin_wall>=ended
 begin=time.monotonic();application=v.apply_kill((ROOT/directive.path).read_text(),directive)
 assert application.targets==application.edits==1 and application.source is not None,(name,application)
 xml=OUT/(name+'.xml')
 with v.mutation_overlay(ROOT,directive.path,application.source) as overlay:
  env=v._overlay_env(ROOT,overlay)
  probe=v._assert_overlay_wins(v._module_name(directive.path),overlay,env,workspace=ROOT)
  assert probe.outcome is v.CommandOutcome.PASS,(name,probe)
  env=v._gate_subprocess_env(ROOT,base_env=env,kill_check=True);invocation=uuid.uuid4().hex;env[v.JUNIT_RUN_ID_ENV]=invocation
  command=v.KILL_CHECK_COMMAND.format(path=shlex.join(record.test_paths))+' -p fa.inner_loop.junit_nodeid_plugin --junitxml='+shlex.quote(str(xml))
  (result,)=v.run_commands((command,),workspace=ROOT,env=env)
  current,error=v._parse_junit_report(xml,run_id=invocation)
 verdict=v._kill_check_result(directive,', '.join(record.test_paths),begin,result,current,error)
 expected=sorted(n for n in manifest if n.partition('::')[0] in record.test_paths)
 counts={k:sum(o.value==k for o in current.outcomes.values()) for k in ['passed','failed','skipped']} if current else None
 row={'name':name,'slice':record.slice_id,'kind':kind,'directive':dataclasses.asdict(directive),'command':command,'run_id':invocation,'started':begin_wall,'baseline_completed':ended,'ordered':begin_wall>=ended,'targets':application.targets,'edits':application.edits,'probe':dataclasses.asdict(probe),'runner':dataclasses.asdict(result),'check':dataclasses.asdict(verdict),'manifest_matches':current is not None and sorted(current.outcomes)==expected,'expected_count':len(expected),'counts':counts,'report_detail':error}
 (OUT/(name+'.json')).write_text(json.dumps(row,indent=2,default=str)+'\n')
 assert hashes()==frozen,(name,'source changed')
 print(json.dumps({k:row[k] for k in ['name','slice','kind','ordered','manifest_matches','expected_count','counts']}|{'verdict':verdict.verdict.value,'duration':verdict.duration_s}),flush=True)
 return row
results=[]
for phase in [[c for c in cases if c[0].slice_id!='SLICE6'],[c for c in cases if c[0].slice_id=='SLICE6']]:
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  for done in concurrent.futures.as_completed([pool.submit(run,c) for c in phase]):
   results.append(done.result());(OUT/'results.json').write_text(json.dumps(results,indent=2,default=str)+'\n')
 assert all(r['check']['verdict'] is v.SliceVerdict.PROVEN and r['manifest_matches'] and r['ordered'] and r['counts']['skipped']==0 and sum(r['counts'].values())==r['expected_count'] for r in results),[(r['name'],r['check']['verdict'],r['report_detail']) for r in results]
assert len(results)==43 and hashes()==frozen and subprocess.check_output(['git','status','--porcelain=v1'])==status
print('ALL40_FUNCTIONAL_PLUS_CT79_AND2_SUPPLEMENTAL_PROVEN_AFTER_COMPLETED_BASELINE; unchanged sources/status',flush=True)
