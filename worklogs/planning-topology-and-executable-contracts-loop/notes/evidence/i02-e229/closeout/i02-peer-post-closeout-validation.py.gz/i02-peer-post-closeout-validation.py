from pathlib import Path
import dataclasses,gzip,hashlib,json,subprocess
from fa.inner_loop.plan_ids import extract_plan_ids
from fa.inner_loop import slice_verification as v
R=Path('worklogs/planning-topology-and-executable-contracts-loop');C=Path('/home/user/.cache/fa-runtime');E=R/'notes/evidence/i02-e229'
before=json.loads((C/'i02-peer-pre-closeout-signatures.json').read_text());actual={}
for r in extract_plan_ids((R/'increments/increment-02-verify-gate-and-kill-checks.md').read_text()).slice_records:
 data=dataclasses.asdict(r);del data['section'];data['kill_directives']={k:dataclasses.asdict(d) for k,d in v.parse_kill_directives(r).items()};actual[r.slice_id]=data
assert json.loads(json.dumps(actual,default=str))==before['slice_signatures']
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before['i03_unchanged'].items())
inputs=json.loads((C/'i02-peer-final-proof-v2/inputs.json').read_text());assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in inputs.items() if p.endswith('.py'))
assert '202 passed in' in (C/'i02-peer-post-doc-conformance.log').read_text() and '13 passed, 77 deselected' in (C/'i02-peer-post-doc-ownership.log').read_text() and 'diagnostics: 0  exit_code: 0' in (C/'i02-peer-post-doc-authoring.log').read_text()
subprocess.run(['git','diff','--check'],check=True)
hook=Path('.git/hooks/commit-msg');assert hashlib.sha256(hook.read_bytes()).hexdigest()=='1a3b9ea63392175d75878b3a6a65a9448ca32af439c644a7cce4bb5cff071b0e'
assert subprocess.check_output(['git','worktree','list','--porcelain'],text=True).count('worktree ')==1
result={'runtime_tests_scripts_unchanged':True,'all_contracts_classes_positions_testpaths_commands_modes_directives_unchanged':True,'i03_plan_spec_bytes_unchanged':True,'doc_parser_skill_conformance':'202 passed in3.01s','ownership_claims':'13 passed77deselected in0.44s','authoring':'0diagnostics/exit0','diff_whitespace':'clean','foreign_hook':'unchanged208bytes','worktrees':1,'scope':'Local I02 closeout only; actual just check rc1 retained, four I03 obligations incomplete.'}
(C/'i02-peer-post-closeout-validation.json').write_text(json.dumps(result,indent=2)+'\n')
# One append-only documentation follow-up to the newly-created E229 record.
p=R/'notes/i02-local-acceptance.md';s=p.read_text();marker='## E223';pos=s.index(marker);s=s[:pos]+'''### E229 post-closeout documentation checks

After the frozen proof exited, only closeout records/evidence changed. All475 tracked Python
source/test/script hashes are unchanged; every slice ID/contract/class/source position/TESTS/
verify command/mode/kill directive remains identical. I03 plan/spec bytes and their unchecked
acceptance obligations are unchanged. Doc/parser/skill/compatibility suite:202passed3.01s;
ownership/claim guards:13passed77deselected0.44s; authoring-check:0diagnostics/exit0;
diff whitespace clean. Historical archives E22081/E22412/E227113/E2285 original/compressed
hashes revalidated. One operator worktree; foreign208-byte commit-msg hook unchanged. This is
not another full wrapper run or a change to its actual red outcome.

'''+s[pos:];p.write_text(s)
p=R/'ledger.md';p.write_text(p.read_text()+'''    E229 documentation follow-up:202 doc/parser/skill/compatibility tests pass;13 ownership guards
    pass77deselected;authoring0diagnostics/exit0;all475Python hashes and extractor binding/positions
    unchanged;I03 plan/spec bytes unchanged;historical211artifact compressed/original hashes verified;
    one worktree,foreign208-byte hook unchanged. No rerun/green label assigned to the failed wrapper.
''')
# Extend original-byte inventory; never rewrite prior archives or report identities.
m=json.loads((E/'manifest.json').read_text())
for name in ['i02-peer-closeout-docs.py','i02-peer-post-closeout-validation.py','i02-peer-post-closeout-validation.json','i02-peer-post-doc-conformance.log','i02-peer-post-doc-ownership.log','i02-peer-post-doc-authoring.log','i02-peer-final-archive.log']:
 raw=(C/name).read_bytes();compressed=gzip.compress(raw,mtime=0);rel='closeout/'+name+'.gz';(E/rel).parent.mkdir(parents=True,exist_ok=True);(E/rel).write_bytes(compressed);m['files'][rel]={'sha256_uncompressed':hashlib.sha256(raw).hexdigest(),'sha256_gzip':hashlib.sha256(compressed).hexdigest(),'bytes_uncompressed':len(raw)}
m['post_closeout']=result;(E/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
for rel,entry in m['files'].items():
 raw=(E/rel).read_bytes();decoded=gzip.decompress(raw);assert hashlib.sha256(raw).hexdigest()==entry['sha256_gzip'] and hashlib.sha256(decoded).hexdigest()==entry['sha256_uncompressed'] and len(decoded)==entry['bytes_uncompressed']
print('Final E229 inventory:',len(m['files']),'lossless artifacts verified; local closeout complete, I03 acceptance incomplete.')
