from pathlib import Path
import gzip,json,collections,xml.etree.ElementTree as ET
from fa.inner_loop import slice_verification as v
R=Path('/home/user/.cache/fa-runtime');archive=Path('worklogs/planning-topology-and-executable-contracts-loop/notes/evidence/i02-e220/repository/i02-d910-final-repository.xml.gz')
run_id=(R/'i02-peer-final-check.uuid').read_text().strip()
report,error=v._parse_junit_report(R/'i02-peer-final-repository.xml',run_id=run_id)
assert report is not None,error

def rows(raw):
 root=ET.fromstring(raw);out={};phases={};reasons={}
 for case in root.iter('testcase'):
  props=[p.get('value') for p in case.findall('./properties/property') if p.get('name')==v.JUNIT_NODEID_PROPERTY]
  assert len(props)==1 and props[0] not in out
  node=props[0];tags=[t for t in ('error','failure','skipped') if case.find(t) is not None]
  outcome=tags[0] if tags else 'passed';out[node]=outcome
  if tags:reasons[node]=(case.find(tags[0]).get('message',''),case.find(tags[0]).text or '')
 return out,reasons
old,_=rows(gzip.decompress(archive.read_bytes()));new,reasons=rows((R/'i02-peer-final-repository.xml').read_bytes())
assert len(new)==5172 and len(old)==4477
assert set(report.outcomes)==set(new)
oldfail={n for n,o in old.items() if o in {'failure','error'}};newfail={n for n,o in new.items() if o in {'failure','error'}}
comparison={'source_commit':'a32a72fc58db4b9a5b048a9b6475649bcf3e32b4','baseline_commit':'d9109f489c84cb7f1ab3568b609d96e5b2b61ae2','candidate_native_run_id':run_id,'candidate_count':len(new),'baseline_count':len(old),'candidate_outcomes':dict(collections.Counter(new.values())),'baseline_outcomes':dict(collections.Counter(old.values())),'new_failures':sorted(newfail-oldfail),'common_failures':sorted(newfail&oldfail),'baseline_only_failures':sorted(oldfail-newfail),'missing_ids':sorted(old.keys()-new.keys()),'new_ids':sorted(new.keys()-old.keys()),'candidate_nonpasses':{n:{'outcome':o,'message':reasons[n][0]} for n,o in new.items() if o!='passed'},'failure_text':{n:reasons[n][1] for n in newfail}}
(R/'i02-peer-final-suite-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
print(json.dumps({k:v for k,v in comparison.items() if k not in {'new_ids','failure_text'}},indent=2));print('new IDs:',len(comparison['new_ids']))
assert not comparison['new_failures'] and len(comparison['common_failures'])==1 and len(comparison['baseline_only_failures'])==8 and len(comparison['missing_ids'])==6 and len(comparison['new_ids'])==701
name=next(iter(newfail));text=reasons[name][1]
assert 'precommit_prewarm_failed' in text and '75' in text
print('Readiness failure remains rc75/precommit_prewarm_failed; no blanket PASS or deployed acceptance inferred.')
