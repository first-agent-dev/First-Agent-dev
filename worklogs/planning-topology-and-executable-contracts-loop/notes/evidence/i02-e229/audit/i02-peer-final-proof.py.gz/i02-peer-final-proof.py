"""E229 affected SLICE5/6 refresh after ratified peer follow-through. No tracked files edited; baseline must complete before kills."""
import concurrent.futures,dataclasses,hashlib,json,os,shlex,subprocess,sys,time,uuid
from pathlib import Path
from fa.inner_loop.plan_ids import extract_plan_ids
from fa.inner_loop import slice_verification as v
ROOT=Path.cwd();OUT=Path('/home/user/.cache/fa-runtime/i02-peer-final-proof');OUT.mkdir(exist_ok=False)
PLAN='worklogs/planning-topology-and-executable-contracts-loop/increments/increment-02-verify-gate-and-kill-checks.md'
SCHEMA='worklogs/planning-topology-and-executable-contracts-loop/notes/artifact-schema-and-grammar.md'
records=extract_plan_ids((ROOT/PLAN).read_text()).slice_records
assert len(records)==7
cases=[]
for record in records:
 directives=v.parse_kill_directives(record)
 functional={k for k,cls,_ in record.contracts if cls=='FUNCTIONAL'}
 assert functional<=directives.keys(),(record.slice_id,functional-directives.keys())
 for name,directive in directives.items():cases.append((record,name,directive,'FUNCTIONAL' if name in functional else 'CONSTRAINT'))
assert len(cases)==41 and sum(kind=='FUNCTIONAL' for _,_,_,kind in cases)==40
s6=next(r for r in records if r.slice_id=='SLICE6')
assert s6.test_paths==('tests/test_verify_gate_live.py',)
cases += [(s6,'SUP-GUARD',v.KillDirective(v.KillOperator.REMOVE_CALL,'src/fa/inner_loop/tools/workflow_tool.py','build_invoke_workflow_tool.handler','_requires_acquisition',0),'SUPPLEMENTAL'),(s6,'SUP-CONTEXT',v.KillDirective(v.KillOperator.REMOVE_CALL,'src/fa/inner_loop/tools/workflow_tool.py','_child_run_context','begin_run',0),'SUPPLEMENTAL')]
cases += [
 (s6,'SUP-FLOW-INTEGRITY',v.KillDirective(v.KillOperator.REMOVE_CALL,'src/fa/inner_loop/workflow_controller.py','_announce_stage','_mark_integrity_failure',0),'SUPPLEMENTAL'),
 (s6,'SUP-T0-STATUS',v.KillDirective(v.KillOperator.REMOVE_CALL,'src/fa/inner_loop/slice_verification.py','capture_test_nodeids','_pytest_report_status_error',0),'SUPPLEMENTAL'),
 (s6,'SUP-DISPATCH-DEADLINE',v.KillDirective(v.KillOperator.REMOVE_CALL,'src/fa/inner_loop/workflow_controller.py','_run_stage','_deadline_exceeded',0),'SUPPLEMENTAL'),
]
assert len(cases) == 46
cases = [c for c in cases if c[0].slice_id in {'SLICE5','SLICE6'}]
cases += [
 (s6,'SUP-INDETERMINATE',v.KillDirective(v.KillOperator.REMOVE_CALL,'src/fa/inner_loop/workflow_controller.py','_effective_controller_route','_verification_is_indeterminate',0),'SUPPLEMENTAL'),
 (s6,'REVIEW-CAPTURE-NARROW',v.KillDirective(v.KillOperator.NEUTRALISE,'src/fa/inner_loop/workflow_controller.py','_capture_nodeids_by_slice',None,0),'REVIEW-ONLY-CONTROL'),
]
assert len(cases)==29
watched=sorted(set(subprocess.check_output(['git','ls-files','--','src/**/*.py','tests/**/*.py','scripts/**/*.py'],text=True).splitlines()+[PLAN,SCHEMA]))
def hashes():return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in watched}
frozen=hashes();status=subprocess.check_output(['git','status','--porcelain=v1'])
(OUT/'inputs.json').write_text(json.dumps(frozen,indent=2)+'\n')
paths=sorted({p for r in records for p in r.test_paths}|{'tests/test_skill_grammar_emit.py','tests/test_planner_emits_schema4.py','tests/test_plan_grammar_live_chain.py'})
env=os.environ.copy();runid=uuid.uuid4().hex;env[v.JUNIT_RUN_ID_ENV]=runid
collect=subprocess.run([sys.executable,'-m','pytest',*paths,'--collect-only','-q'],cwd=ROOT,env=env,capture_output=True,text=True,check=True)
manifest=sorted(l for l in collect.stdout.splitlines() if l.startswith('tests/') and '::' in l)
assert len(manifest)==len(set(manifest))>487
(OUT/'baseline-collection.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Fresh actual unmutated baseline on the changed source; never reuse E220's old snapshot.
begin_wall=time.time();start=time.monotonic()
command=[sys.executable,'-m','pytest',*paths,'-q','-p','fa.inner_loop.junit_nodeid_plugin','--junitxml='+str(OUT/'baseline.xml')]
with (OUT/'baseline.log').open('w') as log:
 completed=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
ended=time.time()
baseline_metadata={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'command':command,'run_id':runid,'started':begin_wall,'completed':ended,'duration_s':time.monotonic()-start,'exit_code':completed.returncode}
(OUT/'baseline.json').write_text(json.dumps(baseline_metadata,indent=2)+'\n')
report,detail=v._parse_junit_report(OUT/'baseline.xml',run_id=runid)
assert completed.returncode==0 and report is not None and sorted(report.outcomes)==manifest and all(o.value=='passed' for o in report.outcomes.values()), (completed.returncode, detail)
assert hashes()==frozen and subprocess.check_output(['git','status','--porcelain=v1'])==status
print(json.dumps({'phase':'FRESH_BASELINE_COMPLETED_BEFORE_MUTATIONS','count':len(manifest),**baseline_metadata}),flush=True)

def run(case):
 record,name,directive,kind=case
 begin_wall=time.time();assert begin_wall>=ended
 begin=time.monotonic();original=(ROOT/directive.path).read_text()
 review_transform=None
 if name=='REVIEW-CAPTURE-NARROW':
  import ast
  nodes=[n for n in ast.parse(original).body if isinstance(n,ast.FunctionDef) and n.name=='_capture_nodeids_by_slice'];assert len(nodes)==1
  node=nodes[0];lines=original.splitlines(keepends=True);block=''.join(lines[node.lineno-1:node.end_lineno])
  old='except Exception as error:';new='except (OSError, ValueError, RuntimeError) as error:';assert block.count(old)==1
  changed=block.replace(old,new);mutated=''.join(lines[:node.lineno-1])+changed+''.join(lines[node.end_lineno:]);ast.parse(mutated)
  application=v.KillApplication(mutated,1,1)
  review_transform='Review-only exact exception-catch narrowing/revert; NOT a new normative kill operator. Neutralise descriptor labels target only.'
 else:
  application=v.apply_kill(original,directive)
 assert application.targets==1 and application.edits>=1 and application.source is not None,(name,application.targets,application.edits)
 xml=OUT/(name+'.xml')
 with v.mutation_overlay(ROOT,directive.path,application.source) as overlay:
  source_root=v._mutation_root(directive.path)
  assert source_root is not None
  module=v._module_name(directive.path)
  env=v._overlay_env(ROOT,overlay,source_root=source_root)
  if source_root=='scripts':env['FA_MUTATION_OVERLAY_MODULE']=module
  probe=v._assert_overlay_wins(module,overlay,env,workspace=ROOT,source_root=source_root)
  assert probe.outcome is v.CommandOutcome.PASS,(name,probe)
  env=v._gate_subprocess_env(ROOT,base_env=env,kill_check=True);invocation=uuid.uuid4().hex;env[v.JUNIT_RUN_ID_ENV]=invocation
  command=v.KILL_CHECK_COMMAND.format(path=shlex.join(record.test_paths))+' -p fa.inner_loop.junit_nodeid_plugin --junitxml='+shlex.quote(str(xml))
  (result,)=v.run_commands((command,),workspace=ROOT,env=env)
  current,error=v._parse_junit_report(xml,run_id=invocation)
 verdict=v._kill_check_result(directive,', '.join(record.test_paths),begin,result,current,error)
 expected=sorted(n for n in manifest if n.partition('::')[0] in record.test_paths)
 counts={k:sum(o.value==k for o in current.outcomes.values()) for k in ['passed','failed','skipped']} if current else None
 row={'name':name,'slice':record.slice_id,'kind':kind,'directive':dataclasses.asdict(directive),'review_transform':review_transform,'source_before_sha256':hashlib.sha256(original.encode()).hexdigest(),'source_after_sha256':hashlib.sha256(application.source.encode()).hexdigest(),'command':command,'run_id':invocation,'started':begin_wall,'baseline_completed':ended,'ordered':begin_wall>=ended,'targets':application.targets,'edits':application.edits,'probe':dataclasses.asdict(probe),'runner':dataclasses.asdict(result),'check':dataclasses.asdict(verdict),'manifest_matches':current is not None and sorted(current.outcomes)==expected,'expected_count':len(expected),'counts':counts,'report_detail':error}
 (OUT/(name+'.json')).write_text(json.dumps(row,indent=2,default=str)+'\n')
 assert hashes()==frozen,(name,'source changed')
 print(json.dumps({k:row[k] for k in ['name','slice','kind','ordered','manifest_matches','expected_count','counts']}|{'verdict':verdict.verdict.value,'duration':verdict.duration_s}),flush=True)
 return row
results=[]
for phase in [[c for c in cases if c[0].slice_id!='SLICE6'],[c for c in cases if c[0].slice_id=='SLICE6']]:
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  for done in concurrent.futures.as_completed([pool.submit(run,c) for c in phase]):
   results.append(done.result());(OUT/'results.json').write_text(json.dumps(results,indent=2,default=str)+'\n')
 assert all(r['check']['verdict'] is v.SliceVerdict.PROVEN and r['manifest_matches'] and r['ordered'] and r['counts']['skipped']==0 and sum(r['counts'].values())==r['expected_count'] for r in results),[(r['name'],r['check']['verdict'],r['report_detail']) for r in results]
assert len(results)==29 and hashes()==frozen and subprocess.check_output(['git','status','--porcelain=v1'])==status
print('ALL22_AFFECTED_FUNCTIONAL_PLUS6_SUPPLEMENTAL_AND1_REVIEW_CONTROL_PROVEN_AFTER_FRESH_BASELINE; unchanged sources/status',flush=True)
