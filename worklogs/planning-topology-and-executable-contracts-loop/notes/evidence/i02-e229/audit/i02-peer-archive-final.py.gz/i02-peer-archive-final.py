"""E229 archive of actual post-Q73 evidence, not a runnable shipping gate."""
from pathlib import Path
import gzip,hashlib,json,platform,subprocess,sys
from fa.inner_loop import slice_verification as v
ROOT=Path.cwd();C=Path('/home/user/.cache/fa-runtime');P=C/'i02-peer-final-proof-v2'
assert (C/'i02-peer-final-proof-v2.rc').read_text().strip()=='0'
assert (C/'i02-peer-final-just-check.rc').read_text().strip()=='1'
rows=json.loads((P/'results.json').read_text());assert len(rows)==29
baseline=json.loads((P/'baseline.json').read_text());head=baseline['source_commit'];assert head=='a32a72fc58db4b9a5b048a9b6475649bcf3e32b4'
manifest=json.loads((P/'baseline-collection.json').read_text());report,error=v._parse_junit_report(P/'baseline.xml',run_id=baseline['run_id'])
assert report is not None and len(report.outcomes)==1002 and sorted(report.outcomes)==manifest and all(o is v._JUnitOutcome.PASSED for o in report.outcomes.values()),error
assert len({r['name'] for r in rows})==29
for r in rows:
 assert r['check']['verdict']=='proven' and r['probe']['outcome']=='pass' and r['ordered'] and r['started']>=baseline['completed']
 assert r['runner']['exit_code']==1 and r['runner']['outcome']=='fail' and r['manifest_matches']
 assert r['counts']['failed']>0 and r['counts']['skipped']==0 and sum(r['counts'].values())==r['expected_count']
 current,detail=v._parse_junit_report(P/(r['name']+'.xml'),run_id=r['run_id']);assert current is not None,detail
 assert sorted(current.outcomes)==[n for n in manifest if n.partition('::')[0] in r['command'].split()]
 assert current.failure_count==r['counts']['failed'] and r['report_detail']==''
assert sum(r['kind']=='FUNCTIONAL' for r in rows)==22 and sum(r['kind']=='SUPPLEMENTAL' for r in rows)==6
review=[r for r in rows if r['kind']=='REVIEW-ONLY-CONTROL'];assert len(review)==1 and review[0]['review_transform'] and review[0]['source_before_sha256']!=review[0]['source_after_sha256']
s6=[r for r in rows if r['slice']=='SLICE6'];assert len(s6)==23 and all(r['expected_count']==596 for r in s6)
inputs=json.loads((P/'inputs.json').read_text());py=[p for p in subprocess.check_output(['git','ls-files','--','src','tests','scripts'],text=True).splitlines() if p.endswith('.py')]
assert set(py)<=inputs.keys() and all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in inputs.items())
assert subprocess.check_output(['git','status','--porcelain=v1'])==b'' and subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
comparison=json.loads((C/'i02-peer-final-suite-comparison.json').read_text());assert comparison['new_failures']==[] and comparison['candidate_count']==5172 and len(comparison['new_ids'])==701
check=(C/'i02-peer-final-just-check.log').read_text()
for label in ['lock-check','lint (ruff+format+deptry+pylint-gap)','typecheck (mypy strict)','typecheck (pyrefly)','authoring-check','contracts (dep+pc+log-kind+no-mock-dc)','shell-syntax (bash -n)']:assert '✓ '+label in check,label
assert '5158 passed, 12 skipped, 1 xfailed' in check
assert '27 cli.py function coverage floors met (78 functions scanned)' in (C/'i02-peer-final-cli-floor.log').read_text()
retained=json.loads((C/'i02-peer-retained-leaf-proof.json').read_text());assert len(retained)==19 and all(not r['current_execution'] and r['slice_section_unchanged'] for r in retained)
coverage=json.loads((ROOT/'coverage.json').read_text())['totals']['percent_covered']
OUT=ROOT/'worklogs/planning-topology-and-executable-contracts-loop/notes/evidence/i02-e229';OUT.mkdir(exist_ok=False);files={}
def put(path,name):
 raw=path.read_bytes();compressed=gzip.compress(raw,mtime=0);(OUT/name).parent.mkdir(parents=True,exist_ok=True);(OUT/name).write_bytes(compressed);files[name]={'sha256_uncompressed':hashlib.sha256(raw).hexdigest(),'sha256_gzip':hashlib.sha256(compressed).hexdigest(),'bytes_uncompressed':len(raw)}
for path in sorted(P.iterdir()):
 if path.is_file():put(path,'ordered/'+path.name+'.gz')
for name in ['i02-peer-historical-archives-validation.json','i02-peer-pre-closeout-signatures.json','i02-peer-final-proof.py','i02-peer-final-proof.log','i02-peer-final-proof-v2.py','i02-peer-final-proof-v2.log','i02-peer-final-proof-v2.rc','i02-peer-archive-final.py','i02-peer-suite-comparison.py','i02-peer-unchanged-leaf-proof.py','i02-peer-retained-leaf-proof.json','i02-peer-help-verification.json','i02-peer-final-just-check.log','i02-peer-final-just-check.rc','i02-peer-final-repository.xml','i02-peer-final-check.uuid','i02-peer-final-suite-comparison.json','i02-peer-final-suite-comparison.log','i02-peer-final-cli-floor.log']:
 put(C/name,('repository/' if any(x in name for x in ['just-check','repository','check.uuid','cli-floor','suite-comparison']) else 'audit/')+name+'.gz')
for name in ['coverage.json','coverage.xml']:put(ROOT/name,'repository/'+name+'.gz')
metadata={'source_commit':head,'baseline_commit':'d9109f489c84cb7f1ab3568b609d96e5b2b61ae2','scope':'local implemented/diff-reviewed proof ONLY; not deployed/OS-boundary/I03 acceptance','environment':{'python':sys.version,'platform':platform.platform()},'encoding':'gzip; original bytes retained; verify both hashes','baseline':baseline,'baseline_cases':1002,'new_invocations':29,'functional':22,'supplemental':6,'review_only_exception_revert_control':1,'slice6_invocations':23,'slice6_cases':596,'retained_earlier_leaf_proofs':19,'retained_proof_origin':'b2b2830/i02-e227;18FUNCTIONAL+CT79; not new execution','inventory_correction':'Original external runner globs omitted295 root Python files. v2 explicitly inventories every tracked Python file under src/tests/scripts and validates committed Git bodies. Reuses the actual completed1002 baseline at identical clean HEAD/native UUID; old hashes not relabeled. Incomplete first affected audit is diagnostic, not closure.','watched_python_files':len(py),'mutations_duration_sum_s':sum(r['check']['duration_s'] for r in rows),'check_rc':1,'repository_summary':{'passed':5158,'failed':1,'skipped':12,'xfailed':1,'total':5172,'coverage_percent':coverage},'comparison':{k:comparison[k] for k in ['new_failures','common_failures','baseline_only_failures','missing_ids']},'new_ids':701,'foreign_commit_msg_hook':{'path':'.git/hooks/commit-msg','bytes':208,'sha256':'1a3b9ea63392175d75878b3a6a65a9448ca32af439c644a7cce4bb5cff071b0e','changed':False},'source_restoration':'Complete per-file inventory and clean Git status unchanged at final audit; only overlays mutated.','files':files}
(OUT/'manifest.json').write_text(json.dumps(metadata,indent=2)+'\n');print('Archived',len(files),'files;29 fresh affected controls/proofs,19 retained earlier leaf proofs; actual check rc1 preserved.')
