"""Validate, do not re-execute, unaffected E227 SLICE1-4 producer proofs."""
from pathlib import Path
import gzip,hashlib,json,subprocess
from fa.inner_loop.plan_ids import extract_plan_ids
ROOT=Path.cwd();P=ROOT/'worklogs/planning-topology-and-executable-contracts-loop/notes/evidence/i02-e227';PLAN='worklogs/planning-topology-and-executable-contracts-loop/increments/increment-02-verify-gate-and-kill-checks.md'
old_inputs=json.loads(gzip.decompress((P/'ordered/inputs.json.gz').read_bytes()))
old_rows=json.loads(gzip.decompress((P/'ordered/results.json.gz').read_bytes()))
old_records={r.slice_id:r for r in extract_plan_ids(subprocess.check_output(['git','show','b2b2830:'+PLAN],text=True)).slice_records}
new_records={r.slice_id:r for r in extract_plan_ids((ROOT/PLAN).read_text()).slice_records}
retained=[]
for r in old_rows:
 if r['slice'] in {'SLICE5','SLICE6'}:continue
 old,new=old_records[r['slice']],new_records[r['slice']]
 assert old.section==new.section and old.test_paths==new.test_paths and old.contracts==new.contracts
 assert r['check']['verdict']=='proven' and r['manifest_matches'] and r['counts']['skipped']==0
 paths=[r['directive']['path'],*old.test_paths]
 hashes={};origins={}
 for path in paths:
  raw=subprocess.check_output(['git','show','b2b2830:'+path]);digest=hashlib.sha256(raw).hexdigest()
  assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest,path
  if path in old_inputs:assert old_inputs[path]==digest
  hashes[path]=digest;origins[path]='original E227 per-file inventory' if path in old_inputs else 'verified committed b2b2830 body; old glob omitted root-level file (not relabeled historical per-file hash)'
 retained.append({'name':r['name'],'slice':r['slice'],'kind':r['kind'],'verdict':'proven','origin':'b2b2830 / i02-e227','current_execution':False,'unchanged_producer_and_test_hashes':hashes,'hash_origin':origins,'slice_section_unchanged':True})
assert len(retained)==19 and sum(r['kind']=='FUNCTIONAL' for r in retained)==18
Path('/home/user/.cache/fa-runtime/i02-peer-retained-leaf-proof.json').write_text(json.dumps(retained,indent=2)+'\n')
print('19 unchanged leaf proofs retained (18 FUNCTIONAL + CT79); no new execution claimed. Changed SLICE5/6 refreshed separately.')
